import datetime as dt
import time
import pandas as pd
import numpy as np

CITY_DATA = { 'chicago': 'chicago.csv',
              'new york city': 'new_york_city.csv',
              'washington': 'washington.csv' }

def get_filters():
  
    
    """
    Asks user to specify a city, month, and day to analyze.

    Returns:
        (str) city - name of the city to analyze
        (str) month - name of the month to filter by, or "all" to apply no month filter
        (str) day - name of the day of week to filter by, or "all" to apply no day filter
    """
    print('Hello! Let\'s explore some US bikeshare data!')
    # TO DO: get user input for city (chicago, new york city, washington). HINT: Use a while loop to handle invalid inputs


    # TO DO: get user input for month (all, january, february, ... , june)
    city = input("Would you like to see data for chicago, new york city, or washington?").lower()
    while city not in ['chicago','new york city','washington'] :
        print('Please enter valid name of city!')
        city = input("Would you like to see data for chicago, new york city, or washington?").lower()
    month = input('which month? January, February, March, April, May, or June? or "all" to apply no month filter').title()
    while month not in ['January','February','March','April','May','June','All'] :
        print('Please enter valid name of month!')
        month = input('which month? January, February, March, April, May, or June? or "all" to apply no month filter').title()
    day = input("Which day? please type name of the day of week to filter by, or 'all' to apply no day filter").title()
    while day not in ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','All']:
        print('Please enter valid name of day!')
        day = input("Which day? please type name of the day of week to filter by, or 'all' to apply no day filter").title()
   

    # TO DO: get user input for day of week (all, monday, tuesday, ... sunday)


    print('-'*40)
    return city, month, day


def load_data(city, month, day):
    try:
        df= pd.read_csv(CITY_DATA[city])
        df['Start Time']=pd.to_datetime(df['Start Time'])
        df['month'] = df['Start Time'].dt.month
        df['day'] = df['Start Time'].dt.dayofweek

        df['hour'] = df['Start Time'].dt.hour

        daysss = {'Tuesday':'1','Wednesday':'2','Thursday':'3','Friday':'4','Saturday':'5','Sunday':'6','Monday':'7'}
        if month != 'All':
            months = ['January', 'February', 'March', 'April', 'May', 'June']
            month = months.index(month) + 1
            df = df[df['month'] == month]

        if day != 'All':
            df = df[df['day'] == int(daysss[day])-1]
    except Exception as Error:
        print(Error)

    """
    Loads data for the specified city and filters by month and day if applicable.

    Args:
        (str) city - name of the city to analyze
        (str) month - name of the month to filter by, or "all" to apply no month filter
        (str) day - name of the day of week to filter by, or "all" to apply no day filter
    Returns:
        df - Pandas DataFrame containing city data filtered by month and day
    """


    return df


def time_stats(df):
    print('\nCalculating The Most Frequent Times of Travel...\n')
    start_time = time.time()

    # TO DO: display the most common month

    most_common_month = df['month'].mode()[0]
    monthss = {'1': 'January', '2': 'February', '3': 'March', '4': 'April', '5': 'May', '6': 'June'}
    m = monthss[str(most_common_month)]

    print("most common month: {} \n".format(m))
    # TO DO: display the most common day of week
    dayss = {'1': 'Tuesday', '2': 'Wednesday', '3': 'Thursday', '4': 'Friday', '5': 'Saturday', '6': 'Sunday',
             '7': 'Monday'}

    most_common_day = df['day'].mode()[0]
    n = dayss[str(most_common_day + 1)]
    print("most common day: {} \n".format(n))

    # TO DO: display the most common start hour
    most_common_start_hour = df['hour'].mode()[0]
    print("most common start hour: {} \n".format(most_common_start_hour))

    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-' * 40)
    """Displays statistics on the most frequent times of travel."""

def station_stats(df):
    """Displays statistics on the most popular stations and trip."""

    print('\nCalculating The Most Popular Stations and Trip...\n')
    start_time = time.time()

    # TO DO: display most commonly used start station
    most_commonly_used_start_station = df['Start Station'].mode()[0]
     
    print("most commonly used start station: {} \n".format(most_commonly_used_start_station))
    # TO DO: display most commonly used end station
    most_commonly_used_end_station = df['End Station'].mode()[0]
    print("most commonly used end station: {} \n".format(most_commonly_used_end_station))
    # TO DO: display most frequent combination of start station and end station trip
    trip=df.groupby(['Start Station','End Station'])
    most_common_trip=trip.size().sort_values(ascending=False).head(1)
    print("most frequent combination of start station and end station trip: \n {} \n".format(most_common_trip))

    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)


def trip_duration_stats(df):
    """Displays statistics on the total and average trip duration."""

    print('\nCalculating Trip Duration...\n')
    start_time = time.time()

    # TO DO: display total travel time
    total_travel_time=df['Trip Duration'].sum()
    average_travel_time=df['Trip Duration'].mean()
    print("Total travel time: {} \nmean travel time: {}".format(total_travel_time,average_travel_time))
                   

    # TO DO: display mean travel time


    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)


def user_stats(df):
    """Displays statistics on bikeshare users."""

    print('\nCalculating User Stats...\n')
    start_time = time.time()

    # TO DO: Display counts of user types
    user_types = df['User Type'].value_counts()
    print(user_types)

    # TO DO: Display counts of gender
    user_genders = df['Gender'].value_counts()
    print(user_genders)
    # TO DO: Display earliest, most recent, and most common year of birth
    earliest = df['Birth Year'].min()
    most_recent = df['Birth Year'].max()
    most_common = df['Birth Year'].mode()[0]
    print("Earliest year of birth : {} \n Most recent year of birth : {} \n Most common year of birth : {}".format(earliest,most_recent,most_common))
    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)


def main():

    while True:
        city, month, day = get_filters()
        df = load_data(city, month, day)
        try:
            time_stats(df)
        except Exception as Error:
            print(Error)
        station_stats(df)
        trip_duration_stats(df)
        if city in ['chicago','new york city']:
            user_stats(df)
        else : print('User statistics of Type and Gender cannot be calculated because Type, Gender do not appear in the dataframe')

        vv= input('do you want to see RAW data? Enter yes or no.\n').lower()
        if vv == 'yes':
            b = 0
            r = 5
            print(df.iloc[b:r])
            nn = input('do you want to continue? Enter yes or no.\n').lower()
            while nn == 'yes':
                b += 5
                r += 5
                print(df.iloc[b:r])
                nn = input('do you want to continue? Enter yes or no.\n').lower()
        restart = input('\nWould you like to restart? Enter yes or no.\n')
        if restart.lower() != 'yes':

            break


if __name__ == "__main__":
	main()
